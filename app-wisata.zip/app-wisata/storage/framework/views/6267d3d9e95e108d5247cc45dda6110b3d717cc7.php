<?php $__env->startSection('content'); ?>
    <form class='form' action="<?php echo e(route('wisatas.update',$wisata->id)); ?>" method="post" enctype="multipart/form-data" class="form">
        <div class="container">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="">Nama</label>
    <input type="text" name="nama" value="<?php echo e($wisata->nama); ?>" class="form-control"><br>

    <label for="">Kota</label>
    <input type="text" name="kota" value="<?php echo e($wisata->kota); ?>" class="form-control"><br>

    <label for="">Harga Tiket</label>
    <input type="text" name="harga_tiket" value="<?php echo e($wisata->harga_tiket); ?>" class="form-control"><br>

    <label for="">Upload Gambar</label>
    <input type="file" name="gambar" class="form-control"><br><br>

    <input type="submit" value="ubah" class="btn btn-primary">
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>