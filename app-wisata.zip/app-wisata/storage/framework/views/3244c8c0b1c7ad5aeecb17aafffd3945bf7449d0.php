<?php $__env->startSection('content'); ?>
<a class="btn btn-primary" href="<?php echo e(route('wisatas.create')); ?>">Tambah Data</a><br><br>
<table class="table table-bordered">
    <div class="container">
    <tr class="text-center table-dark">
        <th>Id</th>
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>

    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="text-center">
        <td><?php echo e($w->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/'.$w->gambar)); ?>" alt="" style="width: 150px;"></td>
        <td><?php echo e($w->nama); ?></td>
        <td><?php echo e($w->kota); ?></td>
        <td><?php echo e($w->harga_tiket); ?></td>
        <td>
            <a class="btn btn-info" href="<?php echo e(route('wisatas.show',$w->id)); ?>">Lihat Data</a>
            <a class="btn btn-warning" href="<?php echo e(route('wisatas.edit',$w->id)); ?>">Ubah Data</a>

            <form onclick="return confirm('anda yakin ingin menghapus data ?')" action="<?php echo e(route('wisatas.destroy',$w->id)); ?>" method="post" style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">Hapus</button>
            </form>
        </td>
    </tr>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php echo e($wisatas->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata/resources/views/wisatas/index.blade.php ENDPATH**/ ?>