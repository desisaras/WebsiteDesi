@extends('wisatas.layout')

@section('content')
<a class="btn btn-primary" href="{{ route('wisatas.create') }}">Tambah Data</a><br><br>
<table class="table table-bordered">
    <div class="container">
    <tr class="text-center table-dark">
        <th>Id</th>
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>

    @foreach($wisatas as $w)
    <tr class="text-center">
        <td>{{ $w->id }}</td>
        <td><img src="{{ Storage::url('public/images/'.$w->gambar) }}" alt="" style="width: 150px;"></td>
        <td>{{ $w->nama }}</td>
        <td>{{ $w->kota }}</td>
        <td>{{ $w->harga_tiket }}</td>
        <td>
            <a class="btn btn-info" href="{{ route('wisatas.show',$w->id) }}">Lihat Data</a>
            <a class="btn btn-warning" href="{{ route('wisatas.edit',$w->id) }}">Ubah Data</a>

            <form onclick="return confirm('anda yakin ingin menghapus data ?')" action="{{ route('wisatas.destroy',$w->id) }}" method="post" style="display:inline;">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger">Hapus</button>
            </form>
        </td>
    </tr>
</div>
    @endforeach

</table>
{{ $wisatas->links() }}

@endsection