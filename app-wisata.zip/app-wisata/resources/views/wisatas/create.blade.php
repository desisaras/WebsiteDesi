@extends('wisatas.layout')

@section('content')
    <form class='form' action="{{ route('wisatas.store') }}" method="post" enctype="multipart/form-data" class="form">
        <div class="container">
    @csrf
    <label for="">Nama</label>
    <input type="text" name="nama" class="form-control"><br>

    <label for="">Kota</label>
    <input type="text" name="kota" class="form-control"><br>

    <label for="">Harga Tiket</label>
    <input type="text" name="harga_tiket" class="form-control"><br>

    <label for="">Upload Gambar</label>
    <input type="file" name="gambar" class="form-control"><br><br>

    <input type="submit" value="Simpan" class="btn btn-primary">
</div>
</form>
@endsection