@extends('wisatas.layout')

@section('content')

<img src="{{ Storage::url('public/images/'. $wisata->gambar) }}" alt="" style="width:200px"><br><br>
<h3>{{ $wisata->nama }}</h3>
<p>{{ $wisata->kota }}</p>
<p>{{ $wisata->harga_tiket }}</p>

<a href="{{ route('wisatas.index') }}" class="btn btn-secondary">Kembali</a>
@endsection